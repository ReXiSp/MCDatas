import json
import os
import shutil
import hashlib

a = json.load(open("models/item/grindstone.json", "r"))
a["overrides"] = []

c = {}

b = json.load(open("origin.json", "r"))

vi = [
    ["pc_loading", 594],
    ["pc_password", 10],
    ["pc_send", 101]
]

last = 0

for v in vi:
    for i in range(0, v[1]):
        try:
            os.rename(f"frame_{i:05}.png", f"{v[0]}_{i:05}.png")
        except Exception:
            pass
        # shutil.de
        try:
            shutil.move(f"{v[0]}_{i:05}.png", "textures/block/pc/" + f"{v[0]}_{i:05}.png")
        except Exception:
            pass

        tex = f"block/pc/{v[0]}_" + f"{i:05}"
        sha = hashlib.sha256(open(f"textures/block/pc/{v[0]}_" + f"{i:05}.png", "rb").read())
        if sha in c.keys():
            tex = c[sha]
            shutil.move("textures/block/pc/" + f"{v[0]}_{i:05}.png", "unused/" + f"{v[0]}_{i:05}.png")
        else:
            c[sha] = tex
        b["textures"]["2"] = tex
        a["overrides"].append({"predicate": { "custom_model_data": i + last + 1}, "model": f"block/pc/{v[0]}_" + f"{i:05}"})
        json.dump(b, open(f"models/block/pc/{v[0]}_" + f"{i:05}.json", "w"), indent=4)

    last += v[1] + 1

json.dump(a, open("models/item/grindstone.json", "w"), indent=4)